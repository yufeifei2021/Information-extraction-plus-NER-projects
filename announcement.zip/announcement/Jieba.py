#  -*-coding:utf8 -*-

"""
Created on 2021 6 25

@author: 陈雨
"""

import re
import jpype
from jpype import *
# 导入jieba模块
import jieba
import jieba.posseg as pseg
import sets
import os
import numpy as np
# 加载自定义词典
from jieba import load_userdict
jieba.load_userdict("./announcement/custom_dictionary.txt") 
#import pandas as pd

# 路径
jvmPath = jpype.getDefaultJVMPath()  # 获得系统的jvm路径
ext_classpath = "E:\\@files(myself)\\HanLP(last)\\hanlp-1.8.2.jar;E:\\@files(myself)\\HanLP(last)"
jvmArg = '-Djava.class.path=' + ext_classpath
jpype.startJVM(jvmPath, jvmArg, "-Xms1g", "-Xmx1g")  # 打开虚拟机

# 繁体转简体
def TraditionalChinese2SimplifiedChinese(sentence_str):
    HanLP = jpype.JClass('com.hankcs.hanlp.HanLP')
    return HanLP.convertToSimplifiedChinese(sentence_str)

# 切词&命名实体识别与词性标注(可以粗略识别)
def NLP_tokenizer(sentence_str):
    NLPTokenizer = jpype.JClass('com.hankcs.hanlp.tokenizer.NLPTokenizer')
    return NLPTokenizer.segment(sentence_str)

# 人名识别,标注为nr
def PersonName_Recognize(sentence_str):
    HanLP = jpype.JClass('com.hankcs.hanlp.HanLP')
    segment = HanLP.newSegment().enableNameRecognize(True)
    return HanLP.segment(sentence_str)

# 标注结果转化成列表
def total_result(function_result_input):
    x = str(function_result_input)
    y = x[1:len(x)-1]
    y = y.split(',')
    return y

# Type_Recognition 可以选 ‘place’,‘person’,‘organization’三种实体,
# 返回单一实体类别的列表
def single_result(Type_Recognition, total_result):
    if Type_Recognition == 'person':
        Type = '/nr'
    else:
        print('请输入正确的参数：')
    z = []
    for i in range(len(total_result)):
        if total_result[i][-3:] == Type:
            z.append(total_result[i])
    return z

# 把单一实体结果汇总成一个字典
def dict_result(sentence_str):
    # 繁体转简体
    sentence = TraditionalChinese2SimplifiedChinese(sentence_str)
    total_dict = {}
    # 人名识别,标注为nr
    c = total_result(PersonName_Recognize(sentence))
    # 返回单一实体类别的列表
    d = single_result('person', c)
    total_list = [i for i in [d, ]]
    total_dict.update(person=total_list[0])
    return total_dict

# 公告
f1 = open('./txtfiles/merge.txt', encoding='utf-8')
text = f1.read()


'''数据清洗'''

print()
print("-----------------------------------------------------------------------------------")
print()

# 创建停用词列表
def stopwordslist():
    #逐行读txt文件，并统一每行加字符串" nr"
    with open('./announcement/StopWords.txt',encoding='UTF-8') as txt:
            # 读全部行
            content = txt.readlines() 
            txt.close()       
    # 去除list中重复的字符串 
    content1 = set(content)
    # 改变输出格式
    content2 = ''.join(content1)
    content3 = content2.replace('\n', ' nr\n')
    # 写入到另一个txt文件中
    with open('./announcement/StopWords_1.txt','w',encoding='UTF-8') as F:
        # 写入
        F.writelines(content3)
        F.close()
    # strip()表示删除掉数据中的换行符
    # split('，')则是数据中遇到‘,’就隔开
    stopwords = [line.strip() for line in open('./announcement/StopWords_1.txt',encoding='UTF-8').readlines()]
    return stopwords    

# # 使用自定义词典
# def custom_dictionary():
#     custom_dictionarys = jieba.load_userdict('./announcement/custom_dictionary.txt')
#     return custom_dictionarys

def process_data(train_file, user_dict=None, stop_dict=None):
    train_file = './txtfiles/announcement.txt'
    stop_dict = './announcement/StopWords.txt'
    # 结巴分词加载自定义词典(要符合jieba自定义词典规范)
    if user_dict:
        jieba.load_userdict(user_dict)
    # 加载停用词表(每行一个停用词)
    stop_words = []
    if stop_dict:
        with open(stop_dict, 'r', encoding='utf-8') as file:
            stop_words = [stop_word.strip() for stop_word in file.readlines()]
    # 读取文件内容并分词, 去掉停用词
    with open(train_file, 'r', encoding='utf-8') as file:
        sentences = file.readlines()
        sentences = [jieba.lcut(sentence.strip()) for sentence in sentences]
        sentences = [[s for s in sentence if s not in stop_words and s.strip() != ''] for sentence in sentences]
    return sentences 


# 分词+人名识别
def hanlp_jieba(a: str):
    for i, value in enumerate(a):
        '''Jieba'''
        words = pseg.cut(value)
        list4 = []
        # 所有分词结果
        for word, flag in words:
            sss = '%s %s' % (word, flag)
            # 挑选出含有nr的分词，注意：这里包含停用词表中的内容
            result_sss = re.findall(
                '([\u4e00-\u9fa5]{2,}\\s\u006e\u0072)', sss) 
            # print(result_sss)
            # 引进停用词列表
            stopwords = stopwordslist() 
            # print(stopwords)
            # # 引进自定义词典
            # custom_dictionarys = custom_dictionary()
            # print(custom_dictionarys)
            
            # 初始化输出结果为outstr
            outstr = ''        
            # 分词后针对result_sss去除nr停止词
            for word in result_sss:
                if word not in stopwords:
                    if word != '\t':
                        outstr += word
                        outstr += " "
            outstr1 = outstr.replace('\n', '')
            if (outstr1):
                list3 = ''.join(outstr1)
                list4.append(list3)
        list5 = ' '.join(list4)
        # 去除nr停止词后文本中的人名
        # print(list5)
        jie1 = list5.replace(' nr', '')
        aa = ''.join(value)
        print(i+1, value, len(value), type(value))
        # print()
        # print('Jieba分词处理结果：')
        # print(jie1)

        '''HanLP'''
        aaa = dict_result(aa)
        values = aaa.values()
        for val in values:
            list1 = val
        list2 = ''.join(list1)
        han1 = list2.replace('/nr', '')
        # print('HanLP包处理结果：')
        # print(han1)
        # print()


print('***************职称变更***************')
'''辞去...'''
result_11 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u8f9e\u53bb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------辞去...----------------')
print()
hanlp_jieba(result_11)


'''提名...'''
result_2222 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u63d0\u540d[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------提名...----------------')
print()
hanlp_jieba(result_2222)


'''聘任***'''
result_33 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u8058\u4efb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------聘任***----------------')
print()
hanlp_jieba(result_33)


'''选举'''
result_44 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u9009\u4e3e[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------选举----------------')
print()
hanlp_jieba(result_44)


'''撤销'''
result_55 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u64a4\u9500[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------撤销----------------')
print()
hanlp_jieba(result_55)


'''***作为'''
result_666 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u4f5c\u4e3a[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------***作为----------------')
print()
hanlp_jieba(result_666)


'''增补'''
result_88 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u589e\u8865[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------增补----------------')
print()
hanlp_jieba(result_88)


'''***离职'''
result_999 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u79bb\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------***离职----------------')
print()
hanlp_jieba(result_999)


'''褫职'''
result_13 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u892b\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------褫职----------------')
print()
hanlp_jieba(result_13)


'''撤职'''
result_12 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u64a4\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------撤职----------------')
print()
hanlp_jieba(result_12)


'''辞任'''
result_14 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u8f9e\u4efb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------辞任----------------')
print()
hanlp_jieba(result_14)


'''辞职'''
result_15 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u8f9e\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------辞职----------------')
print()
hanlp_jieba(result_15)


'''夺职'''
result_16 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u593a\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------夺职----------------')
print()
hanlp_jieba(result_16)


'''革职'''
result_17 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u9769\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------革职----------------')
print()
hanlp_jieba(result_17)


'''解除…关系'''
result_18 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u89e3\u9664[\u4e00-\u9fa5]{1,}\u5173\u7cfb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------解除…关系----------------')
print()
hanlp_jieba(result_18)


'''解雇'''
result_19 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u89e3\u96c7[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------解雇----------------')
print()
hanlp_jieba(result_19)


'''解聘'''
result_20 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u89e3\u8058[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------解聘----------------')
print()
hanlp_jieba(result_20)


'''解职'''
result_21 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u89e3\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------解职----------------')
print()
hanlp_jieba(result_21)


'''开除'''
result_22 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u5f00\u9664[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------开除----------------')
print()
hanlp_jieba(result_22)


'''离任'''
result_23 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u79bb\u4efb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------离任----------------')
print()
hanlp_jieba(result_23)


'''免职'''
result_24 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u514d\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------免职----------------')
print()
hanlp_jieba(result_24)


'''退休'''
result_25 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u9000\u4f11[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------退休----------------')
print()
hanlp_jieba(result_25)


'''违约'''
result_26 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u8fdd\u7ea6[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------违约----------------')
print()
hanlp_jieba(result_26)


'''卸任'''
result_27 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u5378\u4efb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------卸任----------------')
print()
hanlp_jieba(result_27)


'''卸职'''
result_28 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u5378\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------卸职----------------')
print()
hanlp_jieba(result_28)


'''引退'''
result_29 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u5f15\u9000[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------引退----------------')
print()
hanlp_jieba(result_29)


'''隐退'''
result_30 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u9690\u9000[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------隐退----------------')
print()
hanlp_jieba(result_30)


'''代理'''
result_31 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u4ee3\u7406[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------代理----------------')
print()
hanlp_jieba(result_31)


'''返聘'''
result_32 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u8fd4\u8058[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------返聘----------------')
print()
hanlp_jieba(result_32)


'''兼任'''
result_33 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u517c\u4efb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------兼任----------------')
print()
hanlp_jieba(result_33)


'''晋升'''
result_34 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u664b\u5347[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------晋升----------------')
print()
hanlp_jieba(result_34)


'''就职'''
result_35 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u5c31\u804c[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------就职----------------')
print()
hanlp_jieba(result_35)


'''聘请'''
result_36 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u8058\u8bf7[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------聘请----------------')
print()
hanlp_jieba(result_36)


'''任命'''
result_37 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u4efb\u547d[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------任命----------------')
print()
hanlp_jieba(result_37)



'''任用'''
result_38 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u4efb\u7528[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------任用----------------')
print()
hanlp_jieba(result_38)


'''上任'''
result_39 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u4e0a\u4efb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------上任----------------')
print()
hanlp_jieba(result_39)


'''升任'''
result_40 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u5347\u4efb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------升任----------------')
print()
hanlp_jieba(result_40)


'''提拔 '''
result_41 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u63d0\u62d4[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------提拔 ----------------')
print()
hanlp_jieba(result_41)


'''选取'''
result_42 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u9009\u53d6[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------选取----------------')
print()
hanlp_jieba(result_42)


'''担任'''
result_43 = re.findall(
    '([\u002d|(\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}(\uff0c|\uff1b|\u003b){0,1}]{0,}[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}\u62c5\u4efb[\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039]{0,}[(\uff0c|\uff1b|\u003b){0,1}(\u002d|\u007e|\u002c|\u201c|\u201d|\u0041-\u005a|\u0061-\u007a|\u4e00-\u9fa5|\u003c|\u003e|\u300a|\u300b|\uff1a|\u003a|\u002f|\u002f|\u002e|\u0028|\u0029|\uff08|\uff09|\u3001|\u0030-\u0039){0,}]{0,}[\u3002|\uff01])', text)
print()
print('---------------担任----------------')
print()
hanlp_jieba(result_43)


# #人名计数
# countUser = dict_result(s);
# countcount = countUser['person']
# 列表形式
# if countcount:
#     dict={}
#     for item in countcount:
#         dict.update({item:countcount.count(item)})
#     print(dict)

# #pandas模块形式
# result=pd.value_counts(countcount)
# pd.set_option('display.max_rows', 1000000)#显示所有行
# pd.set_option('display.max_columns', 1000000)   # 可以在大数据量下，没有省略号
# print(result)


# print('***************职称***************')
# '''董事长'''
# result_a = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u8463\u4e8b\u957f[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001])', text)
# print()
# print('---------------董事长----------------')
# print()
# hanlp_jieba(result_a)


# '''董事'''
# result_b = re.findall(
#     '([\u4e00-\u9fa5]{1,}(?![关联|现任|独立|独立非执行]).\u8463\u4e8b(?![长|会]).[\u4e00-\u9fa5]{1,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------董事----------------')
# print()
# hanlp_jieba(result_b)


# '''副董事长'''
# result_c = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u526f\u8463\u4e8b\u957f[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------副董事长----------------')
# print()
# hanlp_jieba(result_c)


# '''董事候选人'''
# result_d = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u8463\u4e8b\u5019\u9009\u4eba[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------董事候选人----------------')
# print()
# hanlp_jieba(result_d)


# '''监事'''
# result_e = re.findall(
#     '((?![董事长]).\u76d1\u4e8b(?![龙建]).[\u4e00-\u9fa5]{0,}(?![董事长]).[\uff0c|\u3002|\u3001|\u300b|\uff09|])', text)
# print()
# print('---------------监事----------------')
# print()
# hanlp_jieba(result_e)


# '''监事会成员'''
# result_f = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u76d1\u4e8b\u4f1a\u6210\u5458[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b\uff09|])', text)
# print()
# print('---------------监事----------------')
# print()
# hanlp_jieba(result_f)


# '''高级管理人员'''
# result_g = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u9ad8\u7ea7\u7ba1\u7406\u4eba\u5458[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b\uff09|])', text)
# print()
# print('---------------高级管理人员----------------')
# print()
# hanlp_jieba(result_g)


# '''中层管理人员'''
# result_h = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u4e2d\u5c42\u7ba1\u7406\u4eba\u5458[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b\uff09|])', text)
# print()
# print('---------------中层管理人员----------------')
# print()
# hanlp_jieba(result_h)


# '''总裁'''
# result_i = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u603b\u88c1[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------总裁----------------')
# print()
# hanlp_jieba(result_i)


# '''副总裁'''
# result_j = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u526f\u603b\u88c1[\u4e00-\u9fa5]{0,})', text)
# print()
# print('---------------副总裁----------------')
# print()
# hanlp_jieba(result_j)


# '''员工'''
# result_k = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u5458\u5de5[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------员工----------------')
# print()
# hanlp_jieba(result_k)


# '''核心技术/业务人员'''
# result_l = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u6838\u5fc3\u6280\u672f/\u4e1a\u52a1\u4eba\u5458[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------核心技术/业务人员----------------')
# print()
# hanlp_jieba(result_l)


# '''总经理'''
# result_m = re.findall(
#     '([\u4e00-\u9fa5]{0,}(?![副]]).\u603b\u7ecf\u7406[\u4e00-\u9fa5]{0,}(?![副]]).[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------总经理----------------')
# print()
# hanlp_jieba(result_m)


# '''副总经理'''
# result_n = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u526f\u603b\u7ecf\u7406[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------副总经理----------------')
# print()
# hanlp_jieba(result_n)


# '''董事会秘书'''
# result_o = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u8463\u4e8b\u4f1a\u79d8\u4e66[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------董事会秘书----------------')
# print()
# hanlp_jieba(result_o)


# '''高管'''
# result_p = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u9ad8\u7ba1[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------高管----------------')
# print()
# hanlp_jieba(result_p)


# '''关联董事'''
# result_q = re.findall(
#     '([\u4e00-\u9fa5]{0,}(?![现任|独立|独立非执行]).\u5173\u8054\u8463\u4e8b(?![长|会]).[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------关联董事----------------')
# print()
# hanlp_jieba(result_q)


# '''独立非执行董事'''
# result_r = re.findall(
#     '([\u4e00-\u9fa5]{0,}(?![关联|现任|独立]).\u5173\u8054\u8463\u4e8b(?![长|会]).[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------独立非执行董事----------------')
# print()
# hanlp_jieba(result_r)


# '''现任董事'''
# result_s = re.findall(
#     '([\u4e00-\u9fa5]{0,}(?![关联|独立|独立非执行]).\u73b0\u4efb\u8463\u4e8b(?![长|会]).[\u4e00-\u9fa5]{0,})', text)
# print()
# print('---------------现任董事----------------')
# print()
# hanlp_jieba(result_s)


# '''独立董事'''
# result_t = re.findall(
#     '([\u4e00-\u9fa5]{0,}(?![关联|现任|独立非执行]).\u73b0\u4efb\u8463\u4e8b(?![长|会]).[\u4e00-\u9fa5]{0,})', text)
# print()
# print('---------------独立董事----------------')
# print()
# hanlp_jieba(result_t)


# '''控股股东'''
# result_u = re.findall(
#     '([^\大晟]\u63a7\u80a1\u80a1\u4e1c[^\大晟][\u4e00-\u9fa5]{0,}[^\有限公司][\uff0c|\u3002|\u3001|\u300b|\uff09])', text)
# print()
# print('---------------控股股东----------------')
# print()
# hanlp_jieba(result_u)


# '''非关联股东'''
# result_v = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u975e\u5173\u8054\u80a1\u4e1c)', text)
# print()
# print('---------------非关联股东----------------')
# print()
# hanlp_jieba(result_v)


# '''新老股东'''
# result_w = re.findall('([\u4e00-\u9fa5]{0,}\u65b0\u8001\u80a1\u4e1c)', text)
# print()
# print('---------------新老股东----------------')
# print()
# hanlp_jieba(result_w)


# '''中小股东'''
# result_x = re.findall('([\u4e00-\u9fa5]{0,}\u4e2d\u5c0f\u80a1\u4e1c)', text)
# print()
# print('---------------中小股东----------------')
# print()
# hanlp_jieba(result_x)


# '''委员[\u4e3b\u4efb]*'''
# result_y = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u59d4\u5458(?![会]).)', text)
# print()
# print('---------------委员----------------')
# print()
# hanlp_jieba(result_y)


# '''独立董事委员'''
# result_z = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u72ec\u7acb\u8463\u4e8b\u59d4\u5458(?![会]).)', text)
# print()
# print('---------------独立董事委员----------------')
# print()
# hanlp_jieba(result_z)


# '''外部审计机构代表'''
# result_1 = re.findall(
#     '(\u5916\u90e8\u5ba1\u8ba1\u673a\u6784\u4ee3\u8868)', text)
# print()
# print('---------------外部审计机构代表----------------')
# print()
# hanlp_jieba(result_1)


# '''内部审计人员'''
# result_2 = re.findall('(\u5185\u90e8\u5ba1\u8ba1\u4eba\u5458)', text)
# print()
# print('---------------内部审计人员----------------')
# print()
# hanlp_jieba(result_2)


# '''财务顾问'''
# result_3 = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u8d22\u52a1\u987e\u95ee(?![华鑫]).[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001])', text)
# print()
# print('---------------财务顾问----------------')
# print()
# hanlp_jieba(result_3)


# '''财务人员'''
# result_4 = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u8d22\u52a1\u4eba\u5458[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001])', text)
# print()
# print('---------------财务人员----------------')
# print()
# hanlp_jieba(result_4)


# '''财务总监'''
# result_5 = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u8d22\u52a1\u603b\u76d1[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001])', text)
# print()
# print('---------------财务总监----------------')
# print()
# hanlp_jieba(result_5)


# '''法律顾问'''
# result_6 = re.findall(
#     '([\u4e00-\u9fa5]{0,}\u6cd5\u5f8b\u987e\u95ee[\u4e00-\u9fa5]{0,}[\uff0c|\u3002|\u3001])', text)
# print()
# print('---------------法律顾问----------------')
# print()
# hanlp_jieba(result_6)

jpype.shutdownJVM()  # 关闭JVM虚拟机

# f2 = open('E:/vscode-code/Jieba.txt', encoding='utf-8')
# text2 = f2.read()

# python <E:/anaconda/envs/pyltp/python.exe e:/vscode-code/announcement/Jieba.py> output.txt
# E:/anaconda/envs/pyltp/python.exe e:/vscode-code/announcement/Jieba.py
