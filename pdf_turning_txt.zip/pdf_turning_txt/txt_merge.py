#  -*-coding:utf8 -*-

import os
import os.path
import sys
import io

# 改变标准输出的默认编码
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8') 

# 填入要合并的文件夹名字
filedir = input('填入要合并的文件夹名字\n')  

# 获取文件夹内每个文件的名字
filenames = os.listdir(filedir)
# print(filenames) 

# 以写的方式打开文件，没有则创建
f = open(filedir+'/merge.txt', 'w',encoding='utf-8')  

# 对每个文件进行遍历
for filename in filenames:

    # 将文件夹路径和文件名字合并
    filepath = filedir + '/' + filename 

    # 循环遍历对每一个文件内的数据
    for line in open(filepath,'r', encoding="utf-8"):  
        
         # 将数据每次按行写入f打开的文件中
        f.writelines(line) 

f.close()  # 关闭

# E:/anaconda/envs/pyltp/python.exe e:/vscode-code/pdf_turning_txt/txt_merge.py
# ./pdf_turning_txt/out/

