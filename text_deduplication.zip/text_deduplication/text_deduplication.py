#  -*-coding:utf8 -*-

list01 = []
for i in open('E:/vscode-code/text_deduplication/text_deduplication.txt',encoding='utf-8'):
    if i in list01:
        continue
    list01.append(i)
with open('E:/vscode-code/text_deduplication/text_deduplication.txt-1.txt', 'w') as handle:
    handle.writelines(list01)
 
 
# text_deduplication.txt 源文件
# text_deduplication-1.txt 输出文件